const express = require('express');
const app = express();
app.use(express.json());

app.post('/avaliar', (req, res) => {
  const respostas = req.body.respostas;
  const score = respostas.reduce((total, valor) => total + valor, 0);

  let nivel = 'Baixo';
  if (score > 10) nivel = 'Alto';
  else if (score > 6) nivel = 'Moderado';

  res.json({
    score,
    nivel,
    sugestao: nivel === 'Alto'
      ? 'Encaminhar para avaliação psicológica urgente.'
      : nivel === 'Moderado'
      ? 'Monitorar e reavaliar em 60 dias.'
      : 'Saudável emocionalmente.'
  });
});

app.listen(3000, () => console.log('API Sentire rodando na porta 3000'));
